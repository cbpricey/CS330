﻿// Write your JavaScript code.

const ratingButton = document.getElementById('RatingButton');

// Add a click event listener to redirect to IMDb page
ratingButton.addEventListener('click', function () {
    window.location.href = 'https://www.imdb.com/title/tt11790780/';  // Redirect to IMDb
});
