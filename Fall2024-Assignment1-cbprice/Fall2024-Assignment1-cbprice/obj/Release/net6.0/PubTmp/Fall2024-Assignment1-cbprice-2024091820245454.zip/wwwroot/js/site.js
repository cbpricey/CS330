﻿const dvdLogo = document.getElementById('RatingDiv');
let posX = Math.random() * window.innerWidth;
let posY = Math.random() * window.innerHeight;
let velocityX = 2;
let velocityY = 2;
const logoWidth = dvdLogo.offsetWidth;
const logoHeight = dvdLogo.offsetHeight;

let animationId;  // Variable to hold the animation frame ID
let isPaused = false;  // Track if the animation is paused

// Function to move the DVD logo
function moveLogo() {
    if (!isPaused) {
        posX += velocityX;
        posY += velocityY;

        // Bounce off the left and right edges
        if (posX + logoWidth >= window.innerWidth || posX <= 0) {
            velocityX = -velocityX; // Reverse horizontal direction
        }

        // Bounce off the top and bottom edges
        if (posY + logoHeight >= window.innerHeight || posY <= 0) {
            velocityY = -velocityY; // Reverse vertical direction
        }

        // Apply the new position
        dvdLogo.style.left = `${posX}px`;
        dvdLogo.style.top = `${posY}px`;
    }

    // Continuously update the position
    animationId = requestAnimationFrame(moveLogo);
}

// Event listener to stop the animation when mouse is held down
dvdLogo.addEventListener('mousedown', function () {
    isPaused = true;  // Pause the animation
});

// Event listener to resume the animation when mouse is released
dvdLogo.addEventListener('mouseup', function () {
    isPaused = false;  // Resume the animation
});

// Start the animation
moveLogo();
