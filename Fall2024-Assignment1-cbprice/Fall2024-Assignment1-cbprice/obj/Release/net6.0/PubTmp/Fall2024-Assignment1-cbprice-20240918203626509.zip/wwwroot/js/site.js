﻿const dvdLogo = document.getElementById('RatingDiv');
let posX = Math.random() * (window.innerWidth - 100);  // Initial random X position
let posY = Math.random() * (window.innerHeight - 50);  // Initial random Y position
let velocityX = 2;
let velocityY = 2;
const logoWidth = dvdLogo.offsetWidth;
const logoHeight = dvdLogo.offsetHeight;

let animationId;  // Variable to hold the animation frame ID
let isDragging = false; // Track if the logo is being dragged
let dragStartX = 0;  // Store mouse position when drag starts
let dragStartY = 0;  // Store mouse position when drag starts

const dampingFactor = 0.99;  // Reduces speed by 1% each frame
const minimumSpeed = 2;      // Minimum speed to prevent stopping completely
const maxInitialSpeed = 15;  // Limit maximum speed when releasing after dragging

// Apply initial position
dvdLogo.style.left = `${posX}px`;
dvdLogo.style.top = `${posY}px`;

// Function to move the DVD logo
function moveLogo() {
    if (!isDragging) {
        posX += velocityX;
        posY += velocityY;

        // Apply damping to reduce speed gradually
        velocityX *= dampingFactor;
        velocityY *= dampingFactor;

        // Ensure that velocity doesn't fall below minimum speed
        if (Math.abs(velocityX) < minimumSpeed) velocityX = minimumSpeed * Math.sign(velocityX);
        if (Math.abs(velocityY) < minimumSpeed) velocityY = minimumSpeed * Math.sign(velocityY);

        // Bounce off the left and right edges
        if (posX + logoWidth >= window.innerWidth || posX <= 0) {
            velocityX = -velocityX; // Reverse horizontal direction
        }

        // Bounce off the top and bottom edges
        if (posY + logoHeight >= window.innerHeight || posY <= 0) {
            velocityY = -velocityY; // Reverse vertical direction
        }

        // Apply the new position
        dvdLogo.style.left = `${posX}px`;
        dvdLogo.style.top = `${posY}px`;
    }

    // Continuously update the position
    animationId = requestAnimationFrame(moveLogo);
}

// Event listener to start dragging
dvdLogo.addEventListener('mousedown', function (event) {
    isDragging = true;
    dragStartX = event.clientX - posX;  // Store offset between mouse and logo position
    dragStartY = event.clientY - posY;
    cancelAnimationFrame(animationId);  // Stop the bouncing while dragging
});

// Event listener to stop dragging and continue the animation
document.addEventListener('mouseup', function (event) {
    if (isDragging) {
        isDragging = false;

        // Calculate new velocity based on mouse release direction
        let deltaX = (event.clientX - (posX + dragStartX));
        let deltaY = (event.clientY - (posY + dragStartY));

        // Normalize the velocity so it isn't too slow
        velocityX = deltaX / 10;
        velocityY = deltaY / 10;

        // Limit the initial velocity if it's too high
        velocityX = Math.min(Math.max(velocityX, -maxInitialSpeed), maxInitialSpeed);
        velocityY = Math.min(Math.max(velocityY, -maxInitialSpeed), maxInitialSpeed);

        // Resume the animation
        moveLogo();
    }
});

// Event listener to drag the logo around the screen
document.addEventListener('mousemove', function (event) {
    if (isDragging) {
        posX = event.clientX - dragStartX;
        posY = event.clientY - dragStartY;

        // Apply the new position while dragging
        dvdLogo.style.left = `${posX}px`;
        dvdLogo.style.top = `${posY}px`;
    }
});

// Start the animation
moveLogo();
