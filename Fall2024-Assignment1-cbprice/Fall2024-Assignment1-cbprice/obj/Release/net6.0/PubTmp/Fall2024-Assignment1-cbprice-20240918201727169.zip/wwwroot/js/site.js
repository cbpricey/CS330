﻿const dvdLogo = document.getElementById('RatingDiv');
let posX = Math.random() * window.innerWidth;
let posY = Math.random() * window.innerHeight;
let velocityX = 2;
let velocityY = 2;
const logoWidth = dvdLogo.offsetWidth;
const logoHeight = dvdLogo.offsetHeight;

// Function to move the DVD logo
function moveLogo() {
    posX += velocityX;
    posY += velocityY;

    // Bounce off the left and right edges
    if (posX + logoWidth >= window.innerWidth || posX <= 0) {
        velocityX = -velocityX; // Reverse horizontal direction
    }

    // Bounce off the top and bottom edges
    if (posY + logoHeight >= window.innerHeight || posY <= 0) {
        velocityY = -velocityY; // Reverse vertical direction
    }

    // Apply the new position
    dvdLogo.style.left = `${posX}px`;
    dvdLogo.style.top = `${posY}px`;

    requestAnimationFrame(moveLogo); // Continuously update the position
}

// Start the animation
moveLogo();