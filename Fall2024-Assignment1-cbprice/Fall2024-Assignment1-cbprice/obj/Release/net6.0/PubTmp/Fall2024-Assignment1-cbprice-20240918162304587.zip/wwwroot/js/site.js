﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

// Select the button by its ID
// Select the button by its ID
const ratingButton = document.getElementById('RatingButton');

// Add a click event listener to redirect to IMDb page
ratingButton.addEventListener('click', function () {
    window.location.href = 'https://www.imdb.com/title/tt11790780/';  // Redirect to IMDb
});


