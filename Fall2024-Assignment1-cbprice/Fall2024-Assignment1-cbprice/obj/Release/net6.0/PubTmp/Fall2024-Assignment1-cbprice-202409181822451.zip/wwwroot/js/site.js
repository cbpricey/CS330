﻿// Write your JavaScript code.
const ratingButton = document.getElementById('RatingButton');

// Add a click event listener to open IMDb page in a new tab
ratingButton.addEventListener('click', function () {
    window.open('https://www.imdb.com/title/tt11790780/', '_blank');  // Opens the URL in a new tab
});
